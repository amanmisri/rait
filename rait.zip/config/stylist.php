<?php

return [
    'themes' => [
        /**
         * Absolute paths as to where stylist can discover themes.
         */
        'paths' => [
            base_path('Themes'),
        ],
    ],
];
