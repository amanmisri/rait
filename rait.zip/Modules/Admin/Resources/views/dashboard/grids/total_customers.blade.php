<div class="col-lg-3 col-md-6 col-sm-6">
    <div class="single-grid total-customers">
        <h4>{{ trans('admin::dashboard.total_customers') }}</h4>

        <i class="fa fa-users pull-left" aria-hidden="true"></i>
        <span class="pull-right">{{ $totalCustomers }}</span>
    </div>
</div>
