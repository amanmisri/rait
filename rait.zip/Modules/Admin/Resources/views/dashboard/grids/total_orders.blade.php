<div class="col-lg-3 col-md-6 col-sm-6">
    <div class="single-grid total-orders">
        <h4>{{ trans('admin::dashboard.total_orders') }}</h4>

        <i class="fa fa-shopping-cart pull-left" aria-hidden="true"></i>
        <span class="pull-right">{{ $totalOrders }}</span>
    </div>
</div>
