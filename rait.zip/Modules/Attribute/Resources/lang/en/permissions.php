<?php

return [
    'attributes' => [
        'index' => 'Index Attribute',
        'create' => 'Create Attribute',
        'edit' => 'Edit Attribute',
        'destroy' => 'Delete Attribute',
    ],
    'attribute_sets' => [
        'index' => 'Index Attribute Set',
        'create' => 'Create Attribute Set',
        'edit' => 'Edit Attribute Set',
        'destroy' => 'Delete Attribute Set',
    ],
];
