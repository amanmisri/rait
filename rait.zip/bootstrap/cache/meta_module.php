<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Meta\\Providers\\MetaServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Meta\\Providers\\MetaServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);