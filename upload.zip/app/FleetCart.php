<?php

namespace FleetCart;

class FleetCart
{
    /**
     * The E-mandi version.
     * Later changed to E-mandi
     * @var string
     */
    const VERSION = '1.0.0 Beta';
}
