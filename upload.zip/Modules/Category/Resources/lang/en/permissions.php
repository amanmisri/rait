<?php

return [
    'index' => 'Index Categories',
    'create' => 'Create Categories',
    'edit' => 'Edit Categories',
    'destroy' => 'Delete Categories',
];
