<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\User\\Providers\\UserServiceProvider',
    1 => 'Modules\\User\\Providers\\EventServiceProvider',
    2 => 'Modules\\User\\Providers\\RouteServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\User\\Providers\\UserServiceProvider',
    1 => 'Modules\\User\\Providers\\EventServiceProvider',
    2 => 'Modules\\User\\Providers\\RouteServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);