<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Setting\\Providers\\SettingServiceProvider',
    1 => 'Modules\\Setting\\Providers\\RouteServiceProvider',
    2 => 'Modules\\Setting\\Providers\\EventServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Setting\\Providers\\SettingServiceProvider',
    1 => 'Modules\\Setting\\Providers\\RouteServiceProvider',
    2 => 'Modules\\Setting\\Providers\\EventServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);