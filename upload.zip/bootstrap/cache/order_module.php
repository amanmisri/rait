<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Order\\Providers\\OrderServiceProvider',
    1 => 'Modules\\Order\\Providers\\RouteServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Order\\Providers\\OrderServiceProvider',
    1 => 'Modules\\Order\\Providers\\RouteServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);