<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Wishlist\\Providers\\WishlistServiceProvider',
    1 => 'Modules\\Wishlist\\Providers\\RouteServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Wishlist\\Providers\\WishlistServiceProvider',
    1 => 'Modules\\Wishlist\\Providers\\RouteServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);